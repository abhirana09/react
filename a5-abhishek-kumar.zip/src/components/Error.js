import React from "react";

function Error(){
    return <h1>Oops! page not found</h1>
}

export default Error;